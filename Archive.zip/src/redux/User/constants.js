export const CURRENTUSER = "CURRENTUSER";  
export const TOKEN = "TOKEN"