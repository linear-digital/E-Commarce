import { combineReducers } from 'redux'
import User from './User/reducers';



export default combineReducers({
    User
})