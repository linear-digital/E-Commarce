import MainPage from "@/Components/Pages/MainPage";

export default function Home() {

  return (  
    <>
      <MainPage />
    </>
  );
}
